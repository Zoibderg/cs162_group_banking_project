#include "Menu.h"
#include "MMDA.h"
#include "CheckingAccount.h"
#include "SavingsAccount.h"
#include "CreditAccount.h"
#include "OneYearCD.h"
#include "ThreeMonthCD.h"
#include "SixMonthCD.h"
#include <iostream>
using namespace std;

// Starts the menu system by displaying the main menu
void Menu::start()
{
    displayMainMenu();
}

// Displays the main menu and processes user choices
void Menu::displayMainMenu()
{
    int choice;

    do
    {
        cout << "\nMain Menu:" << endl;
        cout << "1. Account Management" << endl;
        cout << "2. Transaction Management" << endl;
        cout << "3. CD Management" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            displayAccountMenu();
            break;
        case 2:
            displayTransactionMenu();
            break;
        case 3:
            displayCDMenu();
            break;
        case 4:
            cout << "Exiting the system. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 4);
}

// Displays the account management menu and processes user choices
void Menu::displayAccountMenu()
{
    int choice;

    do
    {
        cout << "\nAccount Management Menu:" << endl;
        cout << "1. Add Account" << endl;
        cout << "2. View Account Details" << endl;
        cout << "3. Update Account Information" << endl;
        cout << "4. Delete Account" << endl;
        cout << "5. Back to Main Menu" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            addAccount();
            break;
        case 2:
            cout << "Viewing account details is under development." << endl;
            break;
        case 3:
            cout << "Updating account information is under development." << endl;
            break;
        case 4:
            cout << "Deleting account is under development." << endl;
            break;
        case 5:
            return;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 5);
}

// Displays the transaction management menu and processes user choices
void Menu::displayTransactionMenu()
{
    int choice;

    do
    {
        cout << "\nTransaction Management Menu:" << endl;
        cout << "1. Process Transaction" << endl;
        cout << "2. Cancel Transaction" << endl;
        cout << "3. Back to Main Menu" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Processing transaction is under development." << endl;
            break;
        case 2:
            cout << "Canceling transaction is under development." << endl;
            break;
        case 3:
            return;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 3);
}

// Displays the CD management menu and processes user choices
void Menu::displayCDMenu()
{
    int choice;

    do
    {
        cout << "\nCertificate of Deposit Management Menu:" << endl;
        cout << "1. Add CD" << endl;
        cout << "2. View CD Details" << endl;
        cout << "3. Apply Interest to CDs" << endl;
        cout << "4. Apply Penalty to CDs" << endl;
        cout << "5. Back to Main Menu" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Adding CD is under development." << endl;
            break;
        case 2:
            cout << "Viewing CD details is under development." << endl;
            break;
        case 3:
            cout << "Applying interest to CDs is under development." << endl;
            break;
        case 4:
            cout << "Applying penalties to CDs is under development." << endl;
            break;
        case 5:
            return;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 5);
}

// Adds a new account for a customer
void Menu::addAccount()
{
    cout << "Adding a new account..." << endl;
    Customer* customer = selectOrCreateCustomer();
    if (customer)
    {
        cout << "Select Account Type:" << endl;
        cout << "1. Checking Account" << endl;
        cout << "2. Savings Account" << endl;
        cout << "3. Credit Account" << endl;
        cout << "4. CD Account" << endl;
        int choice;
        cin >> choice;

        BankAccount* account = nullptr;
        switch (choice)
        {
        case 1:
            account = new CheckingAccount(customer);
            break;
        case 2:
            account = new SavingsAccount(customer);
            break;
        case 3:
            account = new CreditAccount(customer);
            break;
        case 4:
            account = new SixMonthCD(customer); // Example CD
            break;
        default:
            cout << "Invalid account type selected." << endl;
            return;
        }

        if (account)
        {
            container.addAccount(account);
            cout << "Account added successfully!" << endl;
        }
    }
}

// Allows selecting an existing customer or creating a new one
Customer* Menu::selectOrCreateCustomer()
{
    int choice;
    cout << "\nCustomer Selection:" << endl;
    cout << "1. Existing Customer" << endl;
    cout << "2. New Customer" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    if (choice == 1)
    {
        string id;
        cout << "Enter Customer ID: ";
        cin >> id;
        return container.findCustomerById(id);
    }
    else if (choice == 2)
    {
        string firstName, lastName;
        cout << "Enter First Name: ";
        cin >> firstName;
        cout << "Enter Last Name: ";
        cin >> lastName;
        Customer* newCustomer = new Customer(firstName, lastName);
        container.addCustomer(newCustomer);
        cout << "New customer created with ID: " << newCustomer->getId() << endl;
        return newCustomer;
    }
    else
    {
        cout << "Invalid choice." << endl;
        return nullptr;
    }
}
