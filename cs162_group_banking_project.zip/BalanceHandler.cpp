#include "BalanceHandler.h"

// Handle balance operations
void BalanceHandler::handleBalance(double balance) {
    // Base implementation - can be overridden by derived classes
} 