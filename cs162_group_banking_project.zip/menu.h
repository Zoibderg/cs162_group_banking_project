#pragma once

#include <string>
#include "BankAccountContainer.h" // Manages accounts and customers

/*
 * Menu class provides the user interface for interacting with the banking system.
 * It offers main menu options and submenus for account, transaction, and CD management.
 */
class Menu
{
private:
    BankAccountContainer container; // Stores customers and accounts

    // Displays the main menu and processes user choices
    void displayMainMenu();

    // Displays the account management menu and processes user choices
    void displayAccountMenu();

    // Displays the transaction management menu and processes user choices
    void displayTransactionMenu();

    // Displays the CD management menu and processes user choices
    void displayCDMenu();

    // Adds a new account for a customer
    void addAccount();

    // Allows selecting an existing customer or creating a new one
    Customer* selectOrCreateCustomer();

public:
    // Starts the menu system
    void start();
};
